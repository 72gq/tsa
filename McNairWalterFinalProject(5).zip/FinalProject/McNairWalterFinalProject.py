"""
Walter McNair
Final Project
SDEV 140
July 30,2022


This program converts a Fahrenheit temperature to Celsius.
It also has 2 images.  It has two windows both with a different image and
alternate text for the image. It has 3 buttons. One to make the F to C
conversion, a second to exit the program and a third to clear the numbers
from the two display fields.  The secondary window has no functions except
to display an image.
"""


from tkinter import *
from PIL import ImageTk,Image#for working with images

#converts fahrenheit(f) to Celsius(c)
def convert():
	temp = float(entry.get())#temp is the f input
	temp =  (temp - 32) * 5/9#temp after the f to c conversion formula
	#This output label will display c output 
	output_label.configure(text = '  {:.1f}  ' .format(temp))

#Clear both display fields
def clear():
        output_label.configure(text='           ')#empty string to output field
        entry.delete(0,END)#delete the input field
        
main_window = Tk()

#Entry and label widgets for data entry
entry = Entry(font=( "Times" , 12), width=5,)
entry.grid(row=0, column=1)
enter_label = Label(text=" Enter a temperature in Fahrenheit...->",
                      font=( "Times" , 12))
enter_label.grid(row=0, column=0)

#label widgets for output
result_label = Label(text="Celsius temperature is...",
                     font=("Times",13)).grid(row=1,column=0)
output_label = Label(relief="sunken",text="            ",
                     font=( "Times" , 12),bg="white",padx=20)
output_label.grid(row=1, column=1)

exit_label = Label(text="End Program Push Exit.....",
                   font=("Times",10)).grid(row=2,column=0)

#Buttons to convert F to C, Clear and Exit
calc_btn = Button(text= " Convert F to C " ,
                     command=convert).grid(row=0, column=2)
clr_btn=Button(main_window, text="Clear",
               command=clear).grid(row=2,column=2)
exit_btn=Button(main_window,text="Exit",
                command=main_window.destroy).grid(row=2,column=1)

#Image for primary window 
my_img =ImageTk.PhotoImage(Image.open("c:/python310/ico/celsius.ico"))
my_label=Label(image=my_img).grid(row=3,column=0)#location
#alternate text  
text_Label=Label(text="Degree Celsius Image",font=("Verdana",20))
text_Label.grid(row=4,column=0)

#Secondary window with image
top=Toplevel()
#image
img=ImageTk.PhotoImage(Image.open('c:/python310/ico/fahrenheit.ico'))
label=Label(top,image=img).grid(row=0,column=0)
#alternate text
Label1=Label(top,text="Degree Fahrenheit Image",font=("Verdana",20)).grid(row=1,column=0)

mainloop()
